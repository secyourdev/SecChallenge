#!/bin/sh
screen -dmS aperisolve docker-compose up