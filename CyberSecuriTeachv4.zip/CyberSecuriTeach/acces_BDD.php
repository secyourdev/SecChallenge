<?php
  
  $BDD= new PDO('mysql:host=localhost;dbname=dbsite;charset=utf8','root','root');
?>